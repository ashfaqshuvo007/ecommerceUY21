<!-- Footer -->
<footer class="py-5 bg-dark">
    <div class="container">
        <p class="m-0  text-white float-left"> &copy; <?php echo date("Y");?> | All rights reserved  </p>
        <p class="m-0  text-white float-right">Developed By <a href="https://www.facebook.com/groups/125925008082831/">UY 21</a></p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

</body>

</html>
