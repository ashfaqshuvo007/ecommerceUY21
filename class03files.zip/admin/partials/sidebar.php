<div class="col-lg-3">

    <h1 class="h3">Categories</h1><br>
    <div class="list-group">
        
        <a href="#" class="list-group-item">Category 1</a>
        
    </div>

</div>