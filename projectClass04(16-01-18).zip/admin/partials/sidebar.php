<div class="col-md-3 mb-5">

    <h1 class="h3">Dashboard</h1><br>
    <div class="list-group">
        
        <a href="category.php" class="list-group-item">Categories</a>
        <a href="password.php" class="list-group-item">Reset Password</a>
        <a href="logout.php" class="list-group-item">Log out</a>
        
    </div>

</div>