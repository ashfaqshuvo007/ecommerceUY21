
<?php $page = 'cart';include_once 'partials/header.php'; ?>

<?php



?>
<!-- Page Content -->
<div class="container">

    <div class="row">

        <?php include_once 'partials/sidebar.php';?>
        <!-- /.col-lg-3 -->

        <div class="col-md-9">

           

            <div class="row">
                
                <div class="col-md-4 col-lg-4 mb-4">                   
                    
                    
                </div>
              
                

            </div>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php';?>
