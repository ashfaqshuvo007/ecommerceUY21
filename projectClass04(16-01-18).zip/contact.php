
<?php $page = 'contact';include_once 'partials/header.php'; ?>
<!-- Page Content -->
<div class="container">

    <div class="row">

   
        <!-- /.col-lg-3 -->

        <div class="col-lg-9">

           

            <div class="row">

                <div class="col-lg-4 col-md-6 mb-4">
                    
                </div>

                

            </div>
            <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

</div>
<!-- /content container -->

<?php include_once 'partials/footer.php';?>